package hospitalmanagement;

import java.util.*;

public class HospitalSystem {
    private final ArrayList<Patient> patients = new ArrayList<>();
    private final Map<String, String> beds = new LinkedHashMap<>();

    public HospitalSystem() {
        for (int i = 1; i <= 10; i++) {
            beds.put(String.format("B%02d", i), null);
        }
    }

    public void registerPatient(Patient p) {
        patients.add(p);
        System.out.println("Patient registered successfully.");
    }

    public Patient searchPatient(String id) {
        for (Patient p : patients) {
            if (p.getId().equalsIgnoreCase(id)) return p;
        }
        return null;
    }

    public boolean updatePatient(String id, String firstName, String lastName, int age, String gender, String condition, String category) {
        Patient p = searchPatient(id);
        if (p == null) return false;
        p.firstName = firstName; p.lastName = lastName; p.age = age;
        p.gender = gender; p.condition = condition; p.category = category;
        return true;
    }

    public boolean deletePatient(String id) {
        Patient p = searchPatient(id);
        if (p == null) return false;
        for (Map.Entry<String, String> e : beds.entrySet()) {
            if (id.equals(e.getValue())) e.setValue(null);
        }
        patients.remove(p);
        return true;
    }

    public void displayAllPatients() {
        if (patients.isEmpty()) { System.out.println("No patients."); return; }
        for (Patient p : patients) p.displayDetails();
    }

    public void allocateBed(String patientId, String bedNumber) {
        Patient p = searchPatient(patientId);
        if (p == null) { System.out.println("Patient not found."); return; }
        if (!beds.containsKey(bedNumber)) { System.out.println("Invalid bed number."); return; }
        if (beds.get(bedNumber) != null) { System.out.println("Bed already occupied."); return; }
        beds.put(bedNumber, patientId);
        if (p instanceof Inpatient inpatient) inpatient.setBedNumber(bedNumber);
        System.out.println("Bed " + bedNumber + " allocated to " + patientId);
    }

    public boolean releaseBed(String bedNumber) {
        if (!beds.containsKey(bedNumber) || beds.get(bedNumber) == null) return false;
        String pid = beds.get(bedNumber);
        beds.put(bedNumber, null);
        Patient p = searchPatient(pid);
        if (p instanceof Inpatient inpatient) inpatient.setBedNumber("");
        System.out.println("Bed " + bedNumber + " released.");
        return true;
    }

    public void displayBedLayout() {
        System.out.println("\n--- Bed Layout ---");
        beds.forEach((bed, pid) -> System.out.println(bed + " : " + (pid == null ? "Available" : "Occupied by " + pid)));
    }

    public void displayAvailableBeds() {
        System.out.println("\n--- Available Beds ---");
        beds.entrySet().stream().filter(e -> e.getValue() == null).forEach(e -> System.out.println(e.getKey()));
    }

    public void displayOccupiedBeds() {
        System.out.println("\n--- Occupied Beds ---");
        beds.entrySet().stream().filter(e -> e.getValue() != null).forEach(e -> System.out.println(e.getKey() + " -> " + e.getValue()));
    }

    public void generateReport() {
        System.out.println("\n--- Ward Report ---");
        System.out.println("Total Patients: " + patients.size());
        long inpatient = patients.stream().filter(p -> p.category.equals("Inpatient")).count();
        System.out.println("Inpatients: " + inpatient + ", Outpatients: " + (patients.size() - inpatient));
        displayBedLayout();
    }

    public void sortBySurname() { patients.sort(Comparator.comparing(Patient::getLastName)); }
    public void sortByPatientId() { patients.sort(Comparator.comparing(Patient::getId)); }

    void addPatient(Patient p) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    Patient findPatient(String id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
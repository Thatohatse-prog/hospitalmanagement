package hospitalmanagement;

public class Inpatient extends Patient {
    private String ward;
    private String bedNumber;

    public Inpatient(String id, String firstName, String lastName, int age, String gender, String condition, String category, String ward, String bedNumber) {
        super(id, firstName);
        this.ward = ward;
        this.bedNumber = bedNumber;
    }

    public String getBedNumber() { return bedNumber; }
    public void setBedNumber(String bedNumber) { this.bedNumber = bedNumber; }
    public void setWard(String ward) { this.ward = ward; }

    @Override
    public void displayDetails() {
        super.displayDetails();
        System.out.println("  Ward: " + ward + ", Bed: " + (bedNumber.isEmpty() ? "Not allocated" : bedNumber));
    }
}
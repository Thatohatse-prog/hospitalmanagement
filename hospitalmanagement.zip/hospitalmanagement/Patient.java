package hospitalmanagement;

public class Patient {
    protected String id, firstName, lastName, gender, condition, category;
    protected int age;

    public Patient(String id, String firstName) {
        this.id = id; this.firstName = firstName; this.lastName = lastName;
        this.age = age; this.gender = gender; this.condition = condition; this.category = category;
    }

    public String getId() { return id; }
    public String getLastName() { return lastName; }

    public void displayDetails() {
        System.out.println("ID: " + id + ", Name: " + firstName + " " + lastName + ", Age: " + age + ", Gender: " + gender + ", Condition: " + condition + ", Category: " + category);
    }
}
package hospitalmanagement;

import java.util.Scanner;

public class Main {

    static Scanner scanner = new Scanner(System.in);
    static HospitalSystem hospital = new HospitalSystem();

    public static void main(String[] args) {
        int choice;
        do {
            displayMenu();
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1 -> registerPatient();
                case 2 -> searchPatient();
                case 3 -> hospital.displayAllPatients();
                case 0 -> System.out.println("Exiting...");
                default -> System.out.println("Invalid choice!");
            }
        } while (choice != 0);
    }

    public static void displayMenu() {
        System.out.println("\n--- Hospital Management ---");
        System.out.println("1. Register Patient");
        System.out.println("2. Search Patient");
        System.out.println("3. View All Patients");
        System.out.println("0. Exit");
    }

    public static void registerPatient() {
        System.out.print("Enter name: ");
        String name = scanner.nextLine();
        System.out.print("Enter ID: ");
        String id = scanner.nextLine();
        Patient p = new Patient(name, id);
        hospital.addPatient(p);
        System.out.println("Patient registered!");
    }

    public static void searchPatient() {
        System.out.print("Enter ID to search: ");
        String id = scanner.nextLine();
        Patient p = hospital.findPatient(id);
        if (p != null) {
            System.out.println(p);
        } else {
            System.out.println("Not found");
        }
    }
}